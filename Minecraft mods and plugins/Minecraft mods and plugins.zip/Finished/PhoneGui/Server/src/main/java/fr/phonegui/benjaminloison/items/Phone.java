package fr.phonegui.benjaminloison.items;

import net.minecraft.item.Item;

public class Phone extends Item
{
    public Phone()
    {
        setUnlocalizedName("phone");
        setMaxStackSize(1);
    }
}