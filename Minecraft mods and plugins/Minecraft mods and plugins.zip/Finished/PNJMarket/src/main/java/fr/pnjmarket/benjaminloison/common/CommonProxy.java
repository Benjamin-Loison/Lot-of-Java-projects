package fr.pnjmarket.benjaminloison.common;

public class CommonProxy
{
    public void registerRender()
    {
        System.out.println("Méthode côté serveur");
    }
}