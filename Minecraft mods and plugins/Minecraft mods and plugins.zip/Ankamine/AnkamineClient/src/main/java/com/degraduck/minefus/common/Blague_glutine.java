package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Blague_glutine
  extends Item
{}
