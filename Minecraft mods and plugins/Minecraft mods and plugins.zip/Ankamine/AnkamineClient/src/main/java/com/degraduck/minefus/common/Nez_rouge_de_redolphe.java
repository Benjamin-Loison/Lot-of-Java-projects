package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Nez_rouge_de_redolphe
  extends Item
{}
