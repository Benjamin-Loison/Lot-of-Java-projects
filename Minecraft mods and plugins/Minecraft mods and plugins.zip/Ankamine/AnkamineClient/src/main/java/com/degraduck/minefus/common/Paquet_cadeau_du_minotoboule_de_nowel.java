package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Paquet_cadeau_du_minotoboule_de_nowel
  extends Item
{}
