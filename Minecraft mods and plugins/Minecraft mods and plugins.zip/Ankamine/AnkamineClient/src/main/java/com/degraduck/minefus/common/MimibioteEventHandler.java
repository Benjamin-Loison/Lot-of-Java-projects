package com.degraduck.minefus.common;

public class MimibioteEventHandler {}
