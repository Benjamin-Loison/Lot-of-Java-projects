package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Fond_de_culotte_de_glugubrr
  extends Item
{}
