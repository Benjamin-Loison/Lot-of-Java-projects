package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Cadeau_de_nowel_potentiellement_surpuissant
  extends Item
{}
