package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Champignon
  extends Item
{}
