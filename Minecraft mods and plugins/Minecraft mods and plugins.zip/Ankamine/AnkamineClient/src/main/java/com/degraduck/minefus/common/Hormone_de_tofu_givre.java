package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Hormone_de_tofu_givre
  extends Item
{}
