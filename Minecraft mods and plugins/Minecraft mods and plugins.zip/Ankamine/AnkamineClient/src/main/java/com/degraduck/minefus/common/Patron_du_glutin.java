package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Patron_du_glutin
  extends Item
{}
