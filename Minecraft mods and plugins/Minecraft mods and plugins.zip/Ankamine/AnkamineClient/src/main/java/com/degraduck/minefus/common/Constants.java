package com.degraduck.minefus.common;

public class Constants
{
  public static final String MODID = "moddofus";
  public static final String MODNAME = "Mods Dofus's";
  public static final String MODVERSION = "Beta 1.0.0";
}
