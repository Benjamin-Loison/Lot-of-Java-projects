package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Patron_de_redolphe
  extends Item
{}
