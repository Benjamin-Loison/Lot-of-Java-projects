package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Clefroyalmouth
  extends Item
{}
