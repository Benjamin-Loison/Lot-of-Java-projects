package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class grainedepiou
  extends Item
{}
