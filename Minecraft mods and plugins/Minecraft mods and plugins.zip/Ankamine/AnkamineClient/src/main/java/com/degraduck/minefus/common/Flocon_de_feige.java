package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Flocon_de_feige
  extends Item
{}
