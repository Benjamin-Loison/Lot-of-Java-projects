package com.degraduck.minefus.items;

import net.minecraft.item.Item;

public class ItemJetonCompensation
  extends Item
{}
