package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Morceaudekamas
  extends Item
{}
