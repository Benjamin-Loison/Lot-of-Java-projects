package com.degraduck.minefus.common;

import net.minecraft.item.Item;

public class Ratelier_doogie_betty
  extends Item
{}
