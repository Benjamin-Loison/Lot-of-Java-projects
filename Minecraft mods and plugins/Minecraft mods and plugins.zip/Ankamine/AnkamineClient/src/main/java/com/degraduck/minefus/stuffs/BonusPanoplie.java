package com.degraduck.minefus.stuffs;

public class BonusPanoplie
{
    public static int bonusBouftouAff, bonusBouftouRoyalAff;
}