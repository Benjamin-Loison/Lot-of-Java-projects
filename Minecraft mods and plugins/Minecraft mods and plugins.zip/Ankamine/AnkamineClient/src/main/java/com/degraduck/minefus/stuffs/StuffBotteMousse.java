package com.degraduck.minefus.stuffs;

import java.util.List;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;

public class StuffBotteMousse
  extends Item
{
  public void addInformation(ItemStack stack, EntityPlayer player, List par3List, boolean par4)
  {
    super.addInformation(stack, player, par3List, par4);
  }
}
